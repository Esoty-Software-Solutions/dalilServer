const { connectDB, dropDB } = require("../config/database");
const mongoose = require("mongoose");
const User = require("../schemas/userSchema");
const Appointment = require("../schemas/appointmentSchema");
// const Audit = require("../schemas/auditSchema");
const Doctor = require("../schemas/doctorSchema");
const GenericService = require("../schemas/genericServiceSchema");
const Institution = require("../schemas/institutionSchema");
const MedicalCenter = require("../schemas/medicalCenterSchema");
const ScheduleSchema = require("../schemas/scheduleSchema");
const SmsSchema = require("../schemas/smsSchema");
const {
  subscribers,
  beneficiaries,
  medicalFiles,
} = require("../schemas/subscriberSchema");
const UserRole = require("../schemas/userRoleSchema");
const UserServices = require("../services/userServices");
const DoctorServices = require("../services/doctorServices");
const SubscriberServices = require("../services/subscriberServices");
const bcrypt = require("bcrypt");
const jwt = require(`jsonwebtoken`);
const UsersData = require("./users.json");
const DoctorData = require("./doctors.json");
const SubscriberData = require("./subscriber.json");

const createData = async () => {
  try {
    for (let i = 0; i < UsersData.length; i++) {
      const hash = bcrypt.hashSync(UsersData[i].password, 10);

      const newBody = {
        ...UsersData[i],
        password: hash,
      };
      await UserServices.createUser(newBody);
      console.log("User created");
    }
  } catch (err) {
    console.error(err);
  }
};

const createDoctorData = async () => {
  try {
    for (let i = 0; i < DoctorData.length; i++) {
      const newBody = {
        ...DoctorData[i],
      };
      await DoctorServices.createDoctor(newBody);
      console.log("Doctor created");
    }
  } catch (err) {
    console.error(err);
  }
};

const createSubscriberData = async () => {
  try {
    for (let i = 0; i < SubscriberData.length; i++) {
      const newBody = {
        ...SubscriberData[i],
      };
      await SubscriberServices.createSubscriber(newBody);
      console.log("Subscriber created");
    }
  } catch (err) {
    console.error(err);
  }
};

const removeData = async () => {
  try {
    //drop databse
    await dropDB();

    //inserting data
    await createData();
    await createDoctorData();
    await createSubscriberData();
    
    process.exit();
  } catch (err) {
    console.error(err);
  }
};

removeData();
